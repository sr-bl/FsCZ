<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8"/>
		<meta http-equiv="Content-Type" content="text/html;"/>
		<meta name="description" content="FsCZ"/>
		<meta name="keywords" content="FsCZ"/>
		<link rel="stylesheet" href="css/bootstrap.css"/>
		<link rel="stylesheet" href="css/style.css"/>
		<title>FsCZ</title>
	</head>
	<body>
		<div class="container">
			<?php include "header.php"; ?>
		</div>
	</body>
</html>